---
name: marketing
description: Comprehensive marketing toolkit covering 50 disciplines — paid ads, SEO and AI search, copywriting, email, pricing, conversion optimization, retention, launches, community, PR, and go-to-market planning. Use whenever the user asks for help marketing or growing a product: writing copy or ads, planning a launch or campaign, optimizing a page or funnel, setting pricing, reducing churn, building an email sequence, researching customers or competitors, or deciding what marketing to do next.
---

# Marketing

A library of 50 marketing playbooks. Each lives in `skills/<name>/SKILL.md`, with deeper
material in that skill's `references/` folder.

## How to use this

1. Match the user's request to a skill in the table below.
2. Read that skill's `skills/<name>/SKILL.md` in full before answering.
3. Read a file from its `references/` folder when the SKILL.md points you to one.
4. If a SKILL.md cross-references another skill ("see `pricing`"), read that one too.

Start with `product-marketing` on a new project — it writes a shared product,
audience, and positioning context file that every other skill reads from, so the
user does not have to re-explain their product on each task.

Do not guess at a skill's method from its name alone. Open the file.

## Skills

| Skill | Use it for |
|---|---|
| `ab-testing` | Plan, design, or implement an A/B test or experiment, or build a growth experimentation program |
| `ad-creative` | Generate, iterate, or scale ad creative — headlines, descriptions, primary text, or full ad variations — for any paid advertising platform |
| `ads` | Help with paid advertising campaigns on Google Ads, Meta (Facebook/Instagram), LinkedIn, Twitter/X, or other ad platforms |
| `ai-seo` | Optimize content for AI search engines, get cited by LLMs, or appear in AI-generated answers |
| `analytics` | Set up, improve, or audit analytics tracking and measurement |
| `aso` | Audit or optimize an App Store or Google Play listing |
| `attribution` | Figure out which marketing actually drives conversions and revenue, choose or interpret an attribution model, or reconcile conflicting numbers across tools |
| `churn-prevention` | Reduce churn, build cancellation flows, set up save offers, recover failed payments, or implement retention strategies |
| `co-marketing` | Find co-marketing partners, plan joint campaigns, or brainstorm partnership opportunities |
| `cold-email` | Write B2B cold emails and follow-up sequences that get replies |
| `community-marketing` | Build and leverage online communities to drive product growth and brand loyalty |
| `competitor-profiling` | Research, profile, or analyze competitors from their URLs |
| `competitors` | Create competitor comparison or alternative pages for SEO and sales enablement |
| `content-strategy` | Plan a content strategy, decide what content to create, or figure out what topics to cover |
| `copy-editing` | Edit, review, or improve existing marketing copy, or refresh outdated content |
| `copywriting` | Write, rewrite, or improve marketing copy for any page — including homepage, landing pages, pricing pages, feature pages, about pages, or product pages |
| `cro` | Optimize, improve, or increase conversions on any marketing page or form — including homepage, landing pages, pricing pages, feature pages, lead capture forms, or contact forms |
| `customer-research` | Conduct, analyze, or synthesize customer research |
| `directory-submissions` | Submit their product to startup, SaaS, AI, agent, MCP, no-code, or review directories for backlinks, domain rating, and discovery |
| `emails` | Create or optimize an email sequence, drip campaign, automated email flow, or lifecycle email program |
| `events` | Plan, run, sponsor, speak at, or get pipeline from events — webinars, conferences, trade shows, meetups, dinners, workshops, virtual summits, or user conferences |
| `free-tools` | Plan, evaluate, or build a free tool for marketing purposes — lead generation, SEO value, or brand awareness |
| `image` | Create, generate, edit, or optimize images for marketing — blog heroes, social graphics, product mockups, profile banners, listing visuals, or brand assets |
| `influencer-marketing` | Run influencer, creator, or ambassador partnerships to promote their product — finding and vetting partners, structuring deals, briefing creators, disclosure compliance, and me |
| `launch` | Plan a product launch, feature announcement, or release strategy |
| `lead-magnets` | Create, plan, or optimize a lead magnet for email capture or lead generation |
| `marketing-council` | Multiple expert perspectives on a marketing question — a simulated board of advisors staffed by legendary marketers (Seth Godin, David Ogilvy, Eugene Schwartz, April Dunford, Rory |
| `marketing-ideas` | Marketing ideas, inspiration, or strategies for their SaaS or software product |
| `marketing-loops` | Set up a recurring, self-running marketing workflow — a repeatable loop an AI agent runs on a cadence (weekly, daily, on a trigger) rather than a one-off task |
| `marketing-plan` | A comprehensive marketing plan for a client, a company they advise, or their own product |
| `marketing-psychology` | Apply psychological principles, mental models, or behavioral science to marketing |
| `offers` | Design, construct, or improve an offer — the thing they actually sell — including value framing, bonus stacking, guarantee design, scarcity/urgency, naming, and payment structu |
| `onboarding` | Optimize post-signup onboarding, user activation, first-run experience, or time-to-value |
| `paywalls` | Create or optimize in-app paywalls, upgrade screens, upsell modals, or feature gates |
| `popups` | Create or optimize popups, modals, overlays, slide-ins, or banners for conversion purposes |
| `pricing` | Help with pricing decisions, packaging, or monetization strategy |
| `product-marketing` | Create or update their product marketing context document |
| `programmatic-seo` | Create SEO-driven pages at scale using templates and data |
| `prospecting` | Find, qualify, and build a list of prospects to reach out to — across B2B SaaS, general B2B, or local small businesses |
| `public-relations` | Help with public relations, earned media, press coverage, journalist outreach, or media strategy (not pull requests) |
| `referrals` | Create, optimize, or analyze a referral program, affiliate program, or word-of-mouth strategy |
| `revops` | Help with revenue operations, lead lifecycle management, or marketing-to-sales handoff processes |
| `sales-enablement` | Create sales collateral, pitch decks, one-pagers, objection handling docs, or demo scripts |
| `schema` | Add, fix, or optimize schema markup and structured data on their site |
| `seo-audit` | Audit, review, or diagnose SEO issues on their site |
| `signup` | Optimize signup, registration, account creation, or trial activation flows |
| `site-architecture` | Plan, map, or restructure their website's page hierarchy, navigation, URL structure, or internal linking |
| `sms` | Plan, build, or optimize SMS or MMS marketing — including welcome flows, abandoned cart texts, post-purchase, win-back, promotional sends, or transactional/auth SMS |
| `social` | Help creating, scheduling, or optimizing social media content for LinkedIn, Twitter/X, Instagram, TikTok, Facebook, or other platforms, or wants to do social listening and engagem |
| `video` | Create, generate, or produce video content using AI tools or programmatic frameworks |
